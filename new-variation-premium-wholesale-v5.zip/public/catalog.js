let allProducts=[],currentFilter='All',settings={};
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const normArr=v=>Array.isArray(v)?v:String(v||'').split(',').map(x=>x.trim()).filter(Boolean);
const colorMap={black:'#111',white:'#fff',grey:'#8a8a8a',gray:'#8a8a8a',olive:'#65704b',green:'#486044',brown:'#76533b',beige:'#c8b99e',navy:'#26354a',blue:'#315d88',red:'#8f3434',khaki:'#a89472',cream:'#e7dfce'};
function dotColor(name){const key=String(name).toLowerCase();return colorMap[key]||'#aaa'}
async function load(){
 const [pr,sr,or]=await Promise.all([fetch('/api/products'),fetch('/api/settings'),fetch('/api/offers')]);
 const parse=async(r)=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Catalogue is unavailable.');return d};
 [allProducts,settings,window._offers]=await Promise.all([parse(pr),parse(sr),parse(or)]);
 renderFilters();renderProducts();renderOffers();applySettings();observeReveal();
}
function applySettings(){
 const n=String(settings.whatsapp||'918384059345').replace(/\D/g,'');
 const wa=n.length===10?'91'+n:n;
 const waUrl='https://wa.me/'+wa;
 ['#waNumber','#floatingWa'].forEach(s=>{const e=$(s);if(e)e.href=waUrl});
 const num=n.length>=10?(n.length===12?'+'+n.slice(0,2)+' '+n.slice(2,7)+' '+n.slice(7):'+91 '+n.slice(-10,-5)+' '+n.slice(-5)):'+91 83840 59345';
 if($('#waNumber'))$('#waNumber').textContent=num;
 document.title=(settings.business_name||'NEW VARIATION')+' | Premium Wholesale Apparel';
}
function renderFilters(){const cats=['All',...new Set(allProducts.map(p=>p.category).filter(Boolean))];$('#filters').innerHTML=cats.map(c=>`<button class="${c===currentFilter?'active':''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}
function renderProducts(){
 const q=($('#search')?.value||'').trim().toLowerCase();let rows=currentFilter==='All'?allProducts:allProducts.filter(p=>p.category===currentFilter);
 if(q)rows=rows.filter(p=>[p.name,p.sku,p.category,p.description,...normArr(p.colors)].join(' ').toLowerCase().includes(q));
 const sort=$('#sort')?.value||'featured';rows=[...rows].sort((a,b)=>sort==='priceLow'?a.price-b.price:sort==='priceHigh'?b.price-a.price:sort==='name'?String(a.name).localeCompare(String(b.name)):Number(b.featured)-Number(a.featured)||b.id-a.id);
 $('#catalogCount').textContent=`${rows.length} product${rows.length===1?'':'s'} available`;
 $('#empty').classList.toggle('d-none',rows.length>0);
 $('#products').innerHTML=rows.map((p,i)=>card(p,i)).join('');
}
function card(p,i){
 const colors=normArr(p.colors),sizes=normArr(p.sizes);const colorHtml=colors.slice(0,4).map(c=>`<span title="${esc(c)}" class="color-dot" style="background:${dotColor(c)}"></span>`).join('');
 const sizeHtml=sizes.slice(0,4).map(s=>`<span class="chip">${esc(s)}</span>`).join('');
 return `<article class="product-card reveal visible" style="transition-delay:${Math.min(i*35,220)}ms"><div class="product-img"><img loading="lazy" src="${esc(p.image||'/assets/product-01.jpg')}" alt="${esc(p.name)}"><span class="badge">${esc(p.badge||'WHOLESALE')}</span><button class="quick" data-quick="${p.id}" aria-label="Quick view">↗</button></div><div class="pinfo"><span class="sku">${esc(p.sku)}</span><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><div class="chips">${colorHtml||'<span class="chip">Multiple colours</span>'}${sizeHtml||'<span class="chip">Size on enquiry</span>'}</div><div class="price-row"><div><div class="price-label">WHOLESALE FROM</div><div class="price">₹${Number(p.price||0).toLocaleString('en-IN')}</div></div><div class="stock">${Number(p.stock)>0?'● In stock':'○ Enquiry'}</div></div><button class="enquire-btn" data-product="${esc(p.name)}">Enquire on WhatsApp →</button></div></article>`;
}
function renderOffers(){const offers=window._offers||[];$('#offersGrid').innerHTML=offers.length?offers.map(o=>`<article class="offer reveal"><b>${esc(o.discount||'WHOLESALE')}</b><h3>${esc(o.title)}</h3><p>${esc(o.description)}</p></article>`).join(''):`<article class="offer reveal"><b>DIRECT QUOTES</b><h3>Tell us your quantity.</h3><p>We can confirm current wholesale pricing and availability for your requirement.</p></article><article class="offer reveal"><b>SIZE MIX</b><h3>Build your assortment.</h3><p>Share your preferred sizes and colour mix when you enquire.</p></article><article class="offer reveal"><b>FAST RESPONSE</b><h3>Talk directly on WhatsApp.</h3><p>Use the enquiry form or floating WhatsApp button to start.</p></article>`;observeReveal()}
function enquire(name){$('#qProduct').value=name;location.hash='contact';setTimeout(()=>$('#qQty').focus(),400)}
function quickView(id){const p=allProducts.find(x=>Number(x.id)===Number(id));if(!p)return;const colors=normArr(p.colors),sizes=normArr(p.sizes);$('#quickContent').innerHTML=`<div class="quick-product"><div class="quick-image"><img src="${esc(p.image||'/assets/product-01.jpg')}" alt="${esc(p.name)}"></div><div class="quick-info"><span class="sku">${esc(p.sku)}</span><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><h4>WHOLESALE PRICE</h4><div class="big-price">₹${Number(p.price||0).toLocaleString('en-IN')}</div><h4>AVAILABLE COLOURS</h4><div class="swatches">${colors.length?colors.map(c=>`<span class="swatch"><span class="color-dot" style="background:${dotColor(c)}"></span>${esc(c)}</span>`).join(''):'On enquiry'}</div><h4>AVAILABLE SIZES</h4><div class="swatches">${sizes.length?sizes.map(s=>`<span class="swatch">${esc(s)}</span>`).join(''):'On enquiry'}</div><h4>STOCK</h4><p>${Number(p.stock)>0?p.stock+' units currently listed':'Please enquire for current availability.'}</p><button class="enquire-btn" data-product="${esc(p.name)}">Enquire about this product →</button></div></div>`;$('#quickModal').classList.add('open');$('#quickModal').setAttribute('aria-hidden','false')}
function closeModal(){$('#quickModal').classList.remove('open');$('#quickModal').setAttribute('aria-hidden','true')}
$('#filters').addEventListener('click',e=>{const b=e.target.closest('[data-cat]');if(!b)return;currentFilter=b.dataset.cat;renderFilters();renderProducts()});
$('#products').addEventListener('click',e=>{const q=e.target.closest('[data-quick]');if(q)return quickView(q.dataset.quick);const b=e.target.closest('[data-product]');if(b)enquire(b.dataset.product)});
$('#offersGrid').addEventListener('click',e=>{const b=e.target.closest('[data-product]');if(b)enquire(b.dataset.product)});
$('#search').addEventListener('input',renderProducts);$('#sort').addEventListener('change',renderProducts);$('#clearSearch').addEventListener('click',()=>{$('#search').value='';$('#sort').value='featured';currentFilter='All';renderFilters();renderProducts()});
$('#printBtn').addEventListener('click',()=>window.print());
document.addEventListener('click',e=>{if(e.target.matches('[data-close]'))closeModal();const b=e.target.closest('[data-product]');if(b&&$('#quickModal').classList.contains('open')){closeModal();enquire(b.dataset.product)}});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
$('#quoteForm').addEventListener('submit',e=>{e.preventDefault();const n=String(settings.whatsapp||'918384059345').replace(/\D/g,'');const wa=n.length===10?'91'+n:n;const msg=`Hello New Variation,%0A%0AI want a wholesale quotation.%0AProduct: ${encodeURIComponent($('#qProduct').value)}%0AQuantity: ${encodeURIComponent($('#qQty').value)}%0ASizes: ${encodeURIComponent($('#qSize').value)}%0AColours: ${encodeURIComponent($('#qColor').value)}%0AName: ${encodeURIComponent($('#qName').value)}%0APhone: ${encodeURIComponent($('#qPhone').value)}`;window.open('https://wa.me/'+wa+'?text='+msg,'_blank')});
$('#menuBtn').addEventListener('click',()=>$('#mobileMenu').classList.toggle('open'));$('#mobileMenu').addEventListener('click',e=>{if(e.target.tagName==='A')$('#mobileMenu').classList.remove('open')});
function observeReveal(){const io=new IntersectionObserver(entries=>entries.forEach(x=>{if(x.isIntersecting){x.target.classList.add('visible');io.unobserve(x.target)}}),{threshold:.12});$$('.reveal:not(.visible)').forEach(x=>io.observe(x))}
load().catch(e=>{console.error(e);$('#products').innerHTML=`<div class="empty" style="grid-column:1/-1"><h3>Catalogue setup required</h3><p>${esc(e.message)}</p></div>`});
